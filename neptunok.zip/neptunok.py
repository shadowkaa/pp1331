# A szamrend szerveren a felhasználói azonosítók a következő könyvtárszerkezetbe rendezettek:
# A user mappán belül először az első karakter, majd az első két karakter, majd a neptun kódok szerint vannak rendezve a felhasználói azonosítók.
# azonosítók="[[a,[[aa, [aab123, aab123, aac123]],[ab,[aba456,abb456,abc456]],[ac,[aca789,acb789,acc789]]]],[b,[ [ba, [baa234,bab234,bac234]],[bb,[bba456,bbb456,bbc456]]]],[c,[ [ca],[cb],[cc] ]]]"
# a) Egy adott elsőbetűhöz mely neptunkódok tartoznak?
# b) Számoljuk meg összesen hány neptun kódhoz tartozó felhasználói azonosító van a user mappában!
# c) Melyik első kétbetűs könyvtár tartalmazza a legtöbb neptunkódot?
#  
# Az adatfájl felépítése a következő:
# az első sorban szóközökkel elválasztva szerepelnek az egyes betűk
# A másodiktól a betükszáma+1 sorban rendre az adott betűkhöz tartozó kétbetűk szerepelnek szóközökkel elválasztva
# Az ezt követő sorokban pedig rendre az adott kétbetűkhöz tartozó neptun kódok szerepelnek szintén szóközökkel elválasztva
with open("neptunok.txt","r") as f:    
    eredmény=[]
    egyesbetűk=f.readline()[:-1].split(" ") #első sorban az egyes betűk
    for betű in egyesbetűk:
        eredmény.append([betű])
    for i in range(len(egyesbetűk)):
        kétbetűk=f.readline()[:-1].split(" ") #aktuális betűhöz tartozó kétbetűk
        eredmény[i].append( [[kétbetű] for kétbetű in kétbetűk])        
        for j in range(len(kétbetűk)):   
            neptunok=f.readline()[:-1].split(" ") #aktuális kétbetűhöz tartozó neptunok
            eredmény[i][1][j].append(neptunok)
        
print(eredmény)

# egy soros megoldás
#Fájlban akár egyetlen sorban is megadhatók az adatok, ha a különböző mélységű listákat más-más karakterrel választjuk el egymástól.
#Például az első szintű listákat a *, a második szinten a , a harmadik szinten a ; és a negyedik szinten a : karakterrel.
#fájlbanadatok="a, aa; aaa:aab:aac ab ; aba;abb;abc, aca;acb;acc * b, ba; baa:bab:bac; bb; bba: bbb: bbc; bc, bca;bcb;bcc"
with open("neptunok2.txt","r") as f:
    fájlbanadatok=f.read()
fájlbanadatok=fájlbanadatok[:-2] #sorvégejel törlése
eredmény=[]
for egybetűs in fájlbanadatok.split("*"):
    kétbetűs=[]
    eredmény.append([egybetűs.split(",")[0],kétbetűs])
    for j in egybetűs.split(",")[1].split("$"):
        kétbetűs.append([j.split(";")[0],j.split(";")[1].split(":")])     
print(eredmény)    

#a) Egy adott elsőbetűhöz mely neptunkódok tartoznak?
elsőbetű=input("Első betű: ")
neptunkódok=[]
for i in range(len(eredmény)):    #egy betűs listában
    if eredmény[i][0]==elsőbetű:
        for j in range(len(eredmény[i][1])): #két betűs listában
            for k in range(len(eredmény[i][1][j][1])): #neptunkódok listában
                neptunkódok.append(eredmény[i][1][j][1][k])                 
print(neptunkódok)

#b) Számoljuk meg összesen hány neptun kódhoz tartozó felhasználói azonosító van a user mappában!
neptunkódok=0
for i in range(len(eredmény)):    #egy betűs listában
    for j in range(len(eredmény[i][1])): #két betűs listában
        neptunkódok+=len(eredmény[i][1][j][1]) #neptunkódok listában            
print("Összesen ennyi neptun kód:",neptunkódok)

#c) Melyik első kétbetűs könyvtár tartalmazza a legtöbb neptunkódot?
max=0
maxkétbetűs=""
for i in range(len(eredmény)):    #egy betűs listában
    for j in range(len(eredmény[i][1])): #két betűs listában
        if len(eredmény[i][1][j][1])>max:
            max=len(eredmény[i][1][j][1])
            maxkétbetűs=eredmény[i][1][j][0]
print("A legtöbb neptunkód a",maxkétbetűs,"könyvtárban található.")